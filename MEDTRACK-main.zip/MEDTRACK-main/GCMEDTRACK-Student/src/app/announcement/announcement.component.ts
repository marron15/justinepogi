// import { Component, OnInit } from '@angular/core';
// import { CommonModule } from '@angular/common';

// @Component({
//   selector: 'app-announcement',
//   standalone: true,
//   imports: [CommonModule],
//   templateUrl: './announcement.component.html',
//   styleUrl: './announcement.component.css'
// })
// export class AnnouncementComponent implements OnInit {
//   constructor() { }

//   ngOnInit(): void {
//   }
// }
